# DBFlow UML Architecture — Source Files & Regeneration Guide

## Contents of this Archive
This archive contains the complete, editable source code for the DBFlow UML Documentation suite:
- `01-use-case/`: Mermaid (`.mmd`) and PlantUML (`.puml`) models for Use Case architecture.
- `02-component/`: Mermaid and PlantUML models for the multi-tier Component architecture.
- `03-class/`: Master Class model and 4 focused sub-diagrams for domain entities and services.
- `04-sequence-database-connection/`: Connection verification and schema introspection sequence models.
- `05-sequence-sql-execution/`: Safe read-only SQL execution and AST validation sequence models.
- `06-sequence-copilot/`: Copilot 2.0 intent routing and autonomous agent loop models.
- `07-activity/`: End-to-end database management operational workflow models.
- `08-deployment/`: Physical and containerized deployment topology models.
- `README.md`: Architectural overview and diagram catalog.
- `scripts/generate-uml-diagrams.mjs`: Automated Node.js + Playwright compilation script.

## How to Edit Diagrams
1. **Mermaid Files (`.mmd`)**:
   - Open in any modern Markdown editor (VS Code with Mermaid Preview, Obsidian, Notion).
   - Or paste into the official online editor: https://mermaid.live
2. **PlantUML Files (`.puml`)**:
   - Open in VS Code with the PlantUML extension.
   - Or paste into the official PlantUML server: http://www.plantuml.com/plantuml/uml/

## How to Regenerate SVG & PNG Deliverables
Ensure Node.js v18+ and Playwright are available:
```bash
npm install -D playwright
node scripts/generate-uml-diagrams.mjs
```
